﻿namespace HashirLab08.Models
{
    public class SignupModel
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Country { get; set; }
    }
}
