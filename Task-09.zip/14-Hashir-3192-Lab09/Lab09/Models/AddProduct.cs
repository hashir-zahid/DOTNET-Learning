﻿namespace Lab09.Models
{
    public class AddProduct
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public float price { get; set; }
    }
}
