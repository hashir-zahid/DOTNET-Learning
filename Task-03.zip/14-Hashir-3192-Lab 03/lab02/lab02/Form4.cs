﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab02
{
    public partial class Form4: Form
    {
        DBconn db = new DBconn();
        public Form4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form2().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            string email = textBox3.Text;
            string position = textBox4.Text;
            string department = textBox5.Text;

            bool success = db.update(username, password, email, position, department);

            if (success)
            {
                MessageBox.Show("Employee details updated successfully.");
                this.Close();
            }
            else
            {
                MessageBox.Show("No employee found with the given EmpID.");
            }
        }
    }
}
